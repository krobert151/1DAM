package ejercicio1;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n1=15, n2=1, n3=6, uno=1;
		int s1=0, s2=0;
		
		System.out.println("Bienvenido al programa que suma tres números y al resultado le resta 1.");
		
		s1= n1+n2+n3;
		s2= s1-uno;
		
		System.out.println(s2);
	}

}
