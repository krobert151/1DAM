package ejercicio5;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double euro=15.00, dolar=1.04, total=0.00; 
		
		System.out.println("Bienvenido a el programa que conversa de euro a dolar");
		
		total=euro*dolar;
		
		System.out.printf("Serian %.2f$\n",total);
		System.out.println("Gracias por usar nuestro prgrama");
	}

}
